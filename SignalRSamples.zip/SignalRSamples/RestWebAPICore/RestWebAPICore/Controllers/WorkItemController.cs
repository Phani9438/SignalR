﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNetCore.Mvc;
using RestWebAPICore.Models;
using HttpGetAttribute = Microsoft.AspNetCore.Mvc.HttpGetAttribute;
using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RestWebAPICore.Controllers
{
    [Route("api/WorkItem")]
    public class WorkItemController : Controller
    {
        List<WorkItem> lstWorkItems = null;
        public WorkItemController()
        {
           
        }                
        // GET api/<controller>
        [HttpGet]
      
        public IActionResult GetWorkItems()
        {
            var lstWorkItems = new List<WorkItem>();
            lstWorkItems.Add(new WorkItem { WorkItemId = 1, DocumentId = "1", AccountNumber = "Acc1" });
            lstWorkItems.Add(new WorkItem { WorkItemId = 2, DocumentId = "2", AccountNumber = "Acc1" });
            lstWorkItems.Add(new WorkItem { WorkItemId = 3, DocumentId = "3", AccountNumber = "Acc3" });
            return Ok(lstWorkItems);
        }

        [HttpGet("{id}")]
        //[Route("WorkItem")]
        public IActionResult Get(int id)
        {
            var lstWorkItems = new List<WorkItem>();
            lstWorkItems.Add(new WorkItem { WorkItemId = 1, DocumentId = "1", AccountNumber = "Acc1" });
            lstWorkItems.Add(new WorkItem { WorkItemId = 2, DocumentId = "2", AccountNumber = "Acc1" });
            lstWorkItems.Add(new WorkItem { WorkItemId = 3, DocumentId = "3", AccountNumber = "Acc3" });
            var workItem = lstWorkItems.Where(x => x.WorkItemId == id);
            return Ok(workItem);
        }
    }
}
