﻿using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using RestWebAPICore.SignalR;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RestWebAPICore.Controllers
{
   

    public class NotificationController : Controller
    {
        private IHubContext<NotifyHub, ITypedHubClient> _hubContext;

        public NotificationController(IHubContext<NotifyHub, ITypedHubClient> hubContext)
        {
            _hubContext = hubContext;
        }

        [Route("api/SendToAllClients")]
        [HttpPost]
        public APIResponse SendTAllClients([FromBody]Person person)
        {
            try
            {
                person.TimeStamp = DateTime.Now.ToString("MM/dd/yyyy hh:mm tt");
                _hubContext.Clients.All.BroadcastMessage(person);
            }
            catch (Exception e)
            {
                return new APIResponse { Message = $"Failed - {e.ToString()}", ErrorCode = (int)HttpStatusCode.InternalServerError };
            }

            return new APIResponse { Message = "Success", ErrorCode = (int)HttpStatusCode.Created };
        }

        public class Person
        {
            public string FirstName { get; set; }

            public string SecondName { get; set; }

            public string TimeStamp { get; set; }
        }

        public class APIResponse
        {
            public string Message { get; set; }
            public int ErrorCode { get; set; }
        }
    }
}
