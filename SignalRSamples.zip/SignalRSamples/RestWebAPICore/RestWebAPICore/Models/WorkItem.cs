﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RestWebAPICore.Models
{
    public class WorkItem
    {
        public int WorkItemId { get; set; }
        [Required]
        [StringLength(4)]
        public string DocumentId { get; set; }
        [Required]
        [StringLength(8, MinimumLength = 8)]
        public string AccountNumber { get; set; }
        //public DateTime DocumentDate { get; set; }

    }
}
