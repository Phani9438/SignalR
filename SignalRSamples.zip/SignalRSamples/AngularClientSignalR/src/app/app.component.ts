import { Component, OnInit } from '@angular/core';
import { HubConnection ,HubConnectionBuilder} from '@aspnet/signalr';
import * as signalR from '@aspnet/signalr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit { 
  title = 'AngularClientSignalR';
  _hubConnection: HubConnection;
  messages: Person[] = [];
  connectionId : number;
  ngOnInit()
  {
    this._hubConnection = new HubConnectionBuilder().withUrl("https://localhost:44326/notify",
                          {
                            skipNegotiation: true,
                            transport: signalR.HttpTransportType.WebSockets,
                            accessTokenFactory: () => "testing"
                         }).build();
    this._hubConnection
      .start()
      .then(() => console.log('Connection started!'))
      .catch(err => console.log('Error while establishing connection :('));
      this._hubConnection.on('BroadcastMessage', (message : Person) => {
        let msg = <Person>message;
        this.messages.push({ firstName: msg.firstName, secondName: msg.secondName , timeStamp : msg.timeStamp});
      });
 
      
    // this.messages.push({ Type: "High", Payload: "First Notification" });
    // this.messages.push({ Type: "High", Payload: "Second Notification" });
  }

  
}

export interface Person {
  firstName : string;
  secondName:String;
  timeStamp:String;
}


